angular.module('Quizz').controller('bandeau', ['$scope', 'webSocket', function($scope, webSocket){
	
	$scope.message = "";
	$scope.showNotification = false;

	$scope.test = function(){
		webSocket.emit('emit', 'Salut');
	}

	webSocket.on('notification', function(data) {
		$scope.$apply(function () {
           $scope.message = data.description;
        });
        if (data.description == "") {
        	$scope.$apply(function () {
           $scope.showNotification = false;
        });}
        else {$scope.showNotification = true;}
	});
}]);

