angular.module('Quizz').controller('quizz', ['$scope', '$http', function($scope,  $http){

	$scope.showSelect = true;
	$scope.showQuizzPrep = false;
	$scope.showQuizz = false;

	$scope.leTheme = null;
	$scope.themes = null;

	$scope.mult = 1.0;
	$scope.nbRep = 3;

	$scope.getQuizz = function() {
		$http
	 	.get('/getQuizzs')
	 	.then(function(response) {
	 		console.log(response.data.quizz);
	 		var ret = [];
	 		response.data.quizz.forEach(function(obj) {
	 			ret.push(obj.thème);
	 		});
	 		$scope.themes = ret;
	 	});
	}

	$scope.launch = function() {
		$scope.showQuizzPrep = false;
		$scope.showQuizz = true  ;
	}

	$scope.quizzPrep = function(data) {
		$scope.showSelect = false;
		$scope.showQuizzPrep = true;
		$scope.leTheme = data;
		$scope.mult = 1.0;
		$scope.nbRep = 3;
	}

	$scope.backHome = function() {
		$scope.showSelect = true;
		$scope.showQuizzPrep = false;
		$scope.showQuizz = false;
		$scope.leTheme = null;
	}

	$scope.setFacile = function() {
		$scope.mult = 0.5;
		$scope.nbRep = 2;
	}

	$scope.setMoyen = function() {
		$scope.mult = 1.0;
		$scope.nbRep = 3;
	}

	$scope.setDifficile = function() {
		$scope.mult = 1.5;
		$scope.nbRep = 4;
	}




}]);