angular.module('Quizz').controller('login',  ['$scope', 'auth', '$http', function($scope, auth, $http){
	
	$scope.isLogged = false;
	$scope.connexionStatus = "UnConnected";

	
	$scope.lastConnexion = localStorage.getItem('session.lastConnexion');
	$scope.humeur = "Coming sOOn";
	$scope.user = getUserFromLocalStorage();

  $scope.load = function() {
    $scope.isLogged = auth.isLoggedIn();
  	}

	$scope.login = function(){
		auth.logIn($scope.username, $scope.password).then(function(data){
			$scope.isLogged = true;
			$scope.connexionStatus = "Connected";
			$scope.user = getUserFromLocalStorage();
			$scope.lastConnexion = localStorage.getItem('session.lastConnexion');
			$scope.humeur = "Coming sOOn";
			//alert(data.statusMsg);
		});

	}

	$scope.logout = function(){
		auth.logOut().then(function(data){
			$scope.isLogged = auth.isLoggedIn();
			$scope.connexionStatus = "Disconnected";
		});
	}

		/*$http.post('/login',$scope.formData).	//ça marche aussi !!!!!
        then(function(response) {
            console.error("Connected");
        }).catch(function(response) {
            console.error("error in posting");
        })*/

    function getUserFromLocalStorage() {	//Enlève les guillments du local storage
		var tmp = localStorage.getItem('session.user');
		if(tmp != null)
		{
			return tmp.substr(1, tmp.length - 2);
		}
		else return null;
	}
}]);

//angular.module('myApp.controllers').controller('Ctrlr1', ['$scope', '$http', function($scope, $http) {}]);