document.writeln("<script type='text/javascript' src='app/app.js'></script>");

//Controllers
document.writeln("<script type='text/javascript' src='app/controllers/login.js'></script>");
document.writeln("<script type='text/javascript' src='app/controllers/bandeau.js'></script>");
document.writeln("<script type='text/javascript' src='app/controllers/quizz.js'></script>");

//Services
document.writeln("<script type='text/javascript' src='app/services/AuthService.js'></script>");
document.writeln("<script type='text/javascript' src='app/services/SessionService.js'></script>");

//Factory
document.writeln("<script type='text/javascript' src='app/services/WebSockets.js'></script>");
