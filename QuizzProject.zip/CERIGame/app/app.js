angular.module('Quizz', [])
/*.controller('login', login)
.service('auth', AuthService)
.service('session', sessionService)*/;